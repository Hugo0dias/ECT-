Simple examples --- Compile with

gcc -Wall -Wextra testing_IntegersQueue.c IntegersQueue.c -o testing_IntegersQueue

gcc -Wall -Wextra testing_PointersQueue.c PointersQueue.c -o testing_PointersQueue


TASK --- Neew example

Create a QUEUE of 2D points and test it !!
