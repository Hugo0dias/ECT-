
Compile with

g++ TestFraction.cpp Fraction.cpp -Wall -Wextra -std=c++17