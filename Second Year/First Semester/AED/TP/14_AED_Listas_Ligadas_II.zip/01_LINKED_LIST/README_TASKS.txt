
Complete the missing functions on the .c file

