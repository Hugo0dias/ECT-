
1 - Complete the missing functions on the .c file

2 - Redo the previous application examples !!