//
// Algoritmos e Estruturas de Dados - 2023/2024
//
// COMPLETE the code, according to Square.h
//

#include "Square.h"

#include <cassert>
#include <iostream>
#include <string>

#include "Point.h"
#include "Rectangle.h"

Square::Square(void) {
  // Rectangle of edge=1 and centered at (0,0)
  // COMPLETE
}

// WRITE THE MISSING CONSTRUTORS, METHODS AND FRIEND FUNCTIONS
