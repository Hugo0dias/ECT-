document.addEventListener('DOMContentLoaded', function () {
  const checkRecordBtn = document.getElementById('checkRecordBtn');
  const favouriteBtn = document.getElementById('favouriteBtn');
  const toast = document.getElementById('toast');
  const favouriteStatus = document.getElementById('favouriteStatus');

  if (checkRecordBtn) {
    checkRecordBtn.addEventListener('click', function () {
      const lastRecord = localStorage.getItem('squat-record') || 'No record found';
      alert(`Your last squat record: ${lastRecord}`);
      const newRecord = prompt('Enter your new record (e.g., 100kg x 5 reps):');
      if (newRecord) {
        localStorage.setItem('squat-record', newRecord);
        this.textContent = 'Record Updated!';
        setTimeout(() => {
          this.textContent = 'Check Record';
        }, 2000);
      }
    });
  }

  if (favouriteBtn && favouriteStatus) {
    favouriteBtn.addEventListener('click', function () {
      const isActive = this.classList.toggle('active');

      // Atualizar estado do texto
      if (isActive) {
        favouriteStatus.classList.remove('hidden');
      } else {
        favouriteStatus.classList.add('hidden');
      }

      // Mostrar mensagem tipo toast
      if (toast) {
        toast.textContent = isActive
          ? 'Added to Favourites ❤️'
          : 'Removed from Favourites 💔';

        toast.classList.remove('hidden');
        toast.classList.add('show');

        setTimeout(() => {
          toast.classList.remove('show');
          toast.classList.add('hidden');
        }, 2000);
      }
    });
  }
});
